from setuptools import setup

setup(name='distributions-shatakshi700',
      version='1.2',
      description='Gaussian and Binomial distributions',
      packages=['distributions-shatakshi700'],
      author = 'Shatakshi Pachori',
      author_email = 'shatakshi700@gmail.com',
      zip_safe=False)
